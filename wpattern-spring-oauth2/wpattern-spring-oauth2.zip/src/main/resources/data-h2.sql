INSERT INTO tb_user (id, name, email, password) 
VALUES (1,'user','user@user.com','password');
